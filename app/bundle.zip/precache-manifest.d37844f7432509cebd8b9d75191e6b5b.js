self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "182376f224be26c936a98b1e9268945f",
    "url": "/index.html"
  },
  {
    "revision": "f5d7316a3ec6e6b81a52",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "f504a333e9d43516b3c8",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "f5d7316a3ec6e6b81a52",
    "url": "/static/js/2.5a725861.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.5a725861.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f504a333e9d43516b3c8",
    "url": "/static/js/main.6c3efed2.chunk.js"
  },
  {
    "revision": "ec9875811aa0f00c2e31",
    "url": "/static/js/runtime-main.92ee656d.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);