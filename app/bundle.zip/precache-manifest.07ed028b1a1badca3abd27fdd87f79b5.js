self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dc6b093ea887e7c6d148a9acba22f986",
    "url": "/index.html"
  },
  {
    "revision": "e3c28b8b8e2cd4b32c79",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "f5be97d0945970a059f9",
    "url": "/static/css/main.7b107ff7.chunk.css"
  },
  {
    "revision": "e3c28b8b8e2cd4b32c79",
    "url": "/static/js/2.9d250674.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.9d250674.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f5be97d0945970a059f9",
    "url": "/static/js/main.24ba1e09.chunk.js"
  },
  {
    "revision": "ec9875811aa0f00c2e31",
    "url": "/static/js/runtime-main.92ee656d.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);