self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7956dca0445bb042cada4cffe06b288a",
    "url": "/index.html"
  },
  {
    "revision": "d68dcbf03cf5f01a60dd",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "2176ce8d6ae49272ef43",
    "url": "/static/css/main.7b107ff7.chunk.css"
  },
  {
    "revision": "d68dcbf03cf5f01a60dd",
    "url": "/static/js/2.8d1b27e7.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.8d1b27e7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2176ce8d6ae49272ef43",
    "url": "/static/js/main.190b015b.chunk.js"
  },
  {
    "revision": "ec9875811aa0f00c2e31",
    "url": "/static/js/runtime-main.92ee656d.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);